paper.GameOver = function() {};

paper.GameOver.prototype = {

    preload : function()
    {
    },

    create : function()
    {
    },

    startLoad: function()
    {
    },

    update : function()
    {
    }  
}
